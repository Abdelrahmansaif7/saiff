export { default as GlobalStyles } from "./GlobalStyles";
